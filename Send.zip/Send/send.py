import pyautogui
import time
import cv2
import numpy as np
import json
import random

def find_and_click(image_path, threshold=0.8, delay=0):
    time.sleep(delay)  # Optional delay
    template = cv2.imread(image_path, 0)  # Load image
    w, h = template.shape[::-1]

    screenshot = np.array(pyautogui.screenshot())
    screenshot_gray = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)

    res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)

    if (loc := np.where(res >= threshold))[0].size > 0:  # Match found
        pyautogui.click(*np.add(cv2.minMaxLoc(res)[3], (w//2, h//2)))
        print(f"Clicked on {image_path}")
    else:
        print(f"No match found for {image_path}")

def find_and_move(image_path, threshold=0.8):
    template = cv2.imread(image_path, 0)
    w, h = template.shape[::-1]

    screenshot_gray = cv2.cvtColor(np.array(pyautogui.screenshot()), cv2.COLOR_BGR2GRAY)
    res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)

    if (loc := np.where(res >= threshold))[0].size > 0:
        pyautogui.moveTo(*np.add(cv2.minMaxLoc(res)[3], (w // 2, h // 2)))
        print(f"Moved to {image_path}")
    else:
        print(f"No match found for {image_path}")

with open(r"C:\Users\Admin\OneDrive\Desktop\tesnet\Send\address.json","r",encoding="utf-8") as file:
    Mata_address = json.load(file)
    
image1 = r"C:\Users\Admin\OneDrive\Desktop\tesnet\Send\image1.png" 
image2 = r"C:\Users\Admin\OneDrive\Desktop\tesnet\Send\image2.png"
image3 = r"C:\Users\Admin\OneDrive\Desktop\tesnet\Send\image3.png"
image4 = r"C:\Users\Admin\OneDrive\Desktop\tesnet\Send\image4.png"
image5 = r"C:\Users\Admin\OneDrive\Desktop\tesnet\Send\image5.png"


time.sleep(2)
for i in range(50):
    find_and_click(image1,delay=2)
    find_and_click(image2,delay=2)
    pyautogui.write("0.0001")
    find_and_click(image3,delay=2)
    pyautogui.write(random.choice(Mata_address))
    find_and_click(image4,delay=2)
    find_and_click(image5,delay=5)
    time.sleep(8)
    print(f"Done {i+1} time.")



