import pyautogui
import time
import cv2
import numpy as np



def find_and_click(image_path, threshold=0.8, delay=0):
    time.sleep(delay)  # Optional delay
    template = cv2.imread(image_path, 0)  # Load image
    w, h = template.shape[::-1]

    screenshot = np.array(pyautogui.screenshot())
    screenshot_gray = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)

    res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)

    if (loc := np.where(res >= threshold))[0].size > 0:  # Match found
        pyautogui.click(*np.add(cv2.minMaxLoc(res)[3], (w//2, h//2)))
        print(f"Clicked on {image_path}")
    else:
        print(f"No match found for {image_path}")

for i in range(50):
    find_and_click(r"C:\Users\Admin\OneDrive\Desktop\tesnet\R2\image1.png",delay=2)
    pyautogui.write("1")
    find_and_click(r"C:\Users\Admin\OneDrive\Desktop\tesnet\R2\image2.png",delay=4)
    find_and_click(r"C:\Users\Admin\OneDrive\Desktop\tesnet\R2\image3.png",delay=6)
    print(f"Done {i+1} time.")
    time.sleep(5)
