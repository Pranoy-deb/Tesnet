import pyautogui
import time
import cv2
import numpy as np
import random
import json


def find_and_click(image_path, threshold=0.8, delay=0):
    time.sleep(delay)  # Optional delay
    template = cv2.imread(image_path, 0)  # Load image
    w, h = template.shape[::-1]

    screenshot = np.array(pyautogui.screenshot())
    screenshot_gray = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)

    res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)

    if (loc := np.where(res >= threshold))[0].size > 0:  # Match found
        pyautogui.click(*np.add(cv2.minMaxLoc(res)[3], (w//2, h//2)))
        print(f"Clicked on {image_path}")
    else:
        print(f"No match found for {image_path}")

with open(r"C:\Users\Admin\OneDrive\Desktop\tesnet\Primus\X_username.json","r") as file:
    X_username = json.load(file)

for i in range(50):
    find_and_click(r"C:\Users\Admin\OneDrive\Desktop\tesnet\Primus\image1.png",delay=2)
    pyautogui.write("0.0001")
    find_and_click(r"C:\Users\Admin\OneDrive\Desktop\tesnet\Primus\image2.png",delay=2)
    pyautogui.write(random.choice(X_username))
    find_and_click(r"C:\Users\Admin\OneDrive\Desktop\tesnet\Primus\image3.png",delay=2)
    find_and_click(r"C:\Users\Admin\OneDrive\Desktop\tesnet\Primus\image4.png",delay=6)
    find_and_click(r"C:\Users\Admin\OneDrive\Desktop\tesnet\Primus\image5.png",delay=15)
    find_and_click(r"C:\Users\Admin\OneDrive\Desktop\tesnet\Primus\image6.png",delay=4)
    time.sleep(6)
    print(f'Done {i+1} time.')
